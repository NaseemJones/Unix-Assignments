#!/bin/bash
echo "Enter a file to be searched"
read inf
sudo find / -type f -name $inf

