#!/bin/bash
echo "Enter two numbers to be read" 
read x y
if [ "$x" -lt 10 ] || [ "$y" -lt 10 ]
then 
	i=1
	echo "Counting up to 1st  value: $x"
	while [ "$i" -lt "$x" ]
	do
		echo "$i"
		i=$(($i+1))
	done
	i=1
	echo "Counting up to 2nd  value: $y"
	while [ "$i" -lt "$y" ]
	do
		echo "$i"
		i=$(($i+1))
	done
else
	echo "Both numbers greater than 10"
	echo $((x+y))
fi
