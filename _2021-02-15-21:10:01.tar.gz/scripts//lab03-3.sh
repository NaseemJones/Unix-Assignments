#!/bin/bash
newline=0
for value in $(mount -l | awk '{print $1,$2,$3,$4,$5'} )
do 
	if [[ "$newline" -lt 4 ]]
	then 
		echo -n "$value "
		((newline=newline+1))
	else
		echo "$value "
		((newline=0))
	fi
done




